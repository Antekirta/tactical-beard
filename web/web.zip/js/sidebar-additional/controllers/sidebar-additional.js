'use strict';

(function () {
	'use strict';

	var sidebarAdditional = angular.module('sidebarAdditional');

	sidebarAdditional.controller('sidebarAdditionalCtrl', ['$scope', function ($scope) {}]);
})();