'use strict';

(function () {
	'use strict';

	var mainMenu = angular.module('mainMenu');

	mainMenu.controller('mainMenuCtrl', ['$scope', function ($scope) {}]);
})();