'use strict';

(function () {
	'use strict';

	var orderDonePage = angular.module('orderDonePage');

	orderDonePage.controller('orderDonePageCtrl', ['$scope', function ($scope) {}]);
})();