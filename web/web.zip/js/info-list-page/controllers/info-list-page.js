'use strict';

(function () {
	'use strict';

	var infoListPage = angular.module('infoListPage');

	infoListPage.controller('infoListPageCtrl', ['$scope', function ($scope) {}]);
})();