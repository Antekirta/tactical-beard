'use strict';

(function () {
	'use strict';

	angular.module('infoPage', []);
})();