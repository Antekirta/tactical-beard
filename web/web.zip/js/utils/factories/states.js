'use strict';

(function () {
    'use strict';

    var utils = angular.module('utils');

    utils.factory('statesFactory', ['$state', '$stateParams', function ($state, $stateParams) {
        return {
            getCurrentState: function getCurrentState() {
                return $state.current;
            },

            changeState: function changeState(state, shouldGo) {
                if (!shouldGo) {
                    $state.go('category', { categoryName: state.params.categoryName });
                }
            }
        };
    }]);
})();