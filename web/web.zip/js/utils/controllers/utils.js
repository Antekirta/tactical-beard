'use strict';

(function () {
	'use strict';

	var utils = angular.module('utils');

	utils.controller('utilsCtrl', ['$scope', function ($scope) {}]);
})();