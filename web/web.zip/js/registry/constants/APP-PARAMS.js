'use strict';

(function () {
    'use strict';

    angular.module('registry').constant('APP_PARAMS', {
        'INTERVAL_BETWEEN_REQUESTS': 100
    });
})();