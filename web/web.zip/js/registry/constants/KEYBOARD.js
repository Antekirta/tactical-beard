'use strict';

(function () {
    'use strict';

    angular.module('registry').constant('KEYBOARD', {
        'ENTER': 13
    });
})();