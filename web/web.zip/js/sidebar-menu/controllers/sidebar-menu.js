'use strict';

(function () {
	'use strict';

	var sidebarMenu = angular.module('sidebarMenu');

	sidebarMenu.controller('sidebarMenuCtrl', ['$scope', function ($scope) {}]);
})();