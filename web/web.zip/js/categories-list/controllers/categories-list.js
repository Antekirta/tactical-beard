'use strict';

(function () {
	'use strict';

	var categoriesList = angular.module('categoriesList');

	categoriesList.controller('categoriesListCtrl', ['$scope', '$log', '$state', 'categoriesProvider', 'translitFactory', 'STATE_NAMES', function ($scope, $log, $state, categoriesProvider, translitFactory, STATE_NAMES) {
		$scope.categories = [];

		$scope.goToUICategoryState = function (state) {
			$state.go(STATE_NAMES.CATEGORY, { categoryId: state.params.categoryId, categoryName: translitFactory.rusTolat(state.params.categoryName) });
		};

		$scope.helpers = {
			sortByOrder: function sortByOrder(a, b) {
				var orderProp = 'sort_order';

				try {
					if (!a.hasOwnProperty(orderProp) || !b.hasOwnProperty(orderProp)) {
						throw new SyntaxError('Wrong parameters in helpers.sortByOrder');
					}

					return a[orderProp] - b[orderProp];
				} catch (err) {
					$log.error(err);
				}
			}
		};

		categoriesProvider.getCategories().then(function (response) {
			var arr = _.toArray(response.data.data.categories);

			arr = _.sortBy(arr, [function (obj) {
				return parseInt(obj[0].sort_order);
			}]);

			_.remove(arr, function (obj) {
				return obj[0].meta_title === '';
			});

			arr.forEach(function (category) {
				category[0].image = '../img/categories/' + category[0].meta_alias + '.svg';
			});

			$scope.categories = arr;
		}, function (error) {
			$log.error(error);
		});
	}]);
})();