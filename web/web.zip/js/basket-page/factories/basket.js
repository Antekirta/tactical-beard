'use strict';

(function () {
    'use strict';

    angular.module('basketPage').factory('basketFactory', ['$rootScope', 'LOCALSTORAGE', 'EVENTS', function ($rootScope, LOCALSTORAGE, EVENTS) {
        var basket;

        if (localStorage.getItem(LOCALSTORAGE.BASKET)) {
            basket = JSON.parse(localStorage.getItem(LOCALSTORAGE.BASKET)) || [];
        } else {
            basket = [];
        }

        return {
            client: {
                getAllProducts: function getAllProducts() {
                    return basket;
                },

                getProductById: function getProductById(id) {
                    var index = _.findIndex(basket, function (product) {
                        return product.id === id;
                    });

                    return basket[index];
                },

                getBasketLength: function getBasketLength() {
                    return _.toArray(JSON.parse(localStorage.getItem(LOCALSTORAGE.BASKET))).length;
                },

                putProduct: function putProduct(product) {
                    var index = _.findIndex(basket, function (element) {
                        return element.id === product.id;
                    });

                    if (index !== -1) {
                        this.updateQuantity(product.id, product.quantity);
                    } else {
                        basket.push(product);
                    }

                    this.updateBasketStorage();
                },

                updateQuantity: function updateQuantity(id, quantity) {
                    var index = _.findIndex(basket, function (product) {
                        return product.id === id;
                    });

                    basket[index].quantity += quantity;

                    this.updateBasketStorage();
                },

                deleteAllProducts: function deleteAllProducts() {
                    basket = [];

                    this.updateBasketStorage();
                },

                deleteProductById: function deleteProductById(id) {
                    var index = _.findIndex(basket, function (product) {
                        return product.id === id;
                    });

                    basket.splice(index, 1);

                    this.updateBasketStorage();
                },

                updateBasketStorage: function updateBasketStorage() {
                    localStorage.setItem(LOCALSTORAGE.BASKET, JSON.stringify(basket));

                    $rootScope.$broadcast(EVENTS.BASKET_EVENTS, {});
                }
            },

            server: {
                getAllProducts: function getAllProducts() {
                    return basket;
                },

                getProductById: function getProductById(id) {
                    var index = _.findIndex(basket, function (product) {
                        return product.id === id;
                    });

                    return basket[index];
                },

                putProduct: function putProduct(product) {
                    basket.push(product);
                }
            }
        };
    }]);
})();