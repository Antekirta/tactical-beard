(function() {
	'use strict';

	var pageContent = angular.module('pageContent');

	pageContent.controller('pageContentCtrl', ['$scope', function($scope) {

	}]);
})();