(function() {
	'use strict';

	angular.module('pageContent', []);
})();