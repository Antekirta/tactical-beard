(function() {
	'use strict';

	angular.module('categoriesSidebar', []);
})();