(function() {
	'use strict';

	angular.module('impulseProducts', []);
})();