(function() {
	'use strict';

	angular.module('slider', []);
})();