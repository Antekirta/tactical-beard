(function() {
	'use strict';

	angular.module('siteHeader', []);
})();