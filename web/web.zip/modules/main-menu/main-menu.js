(function() {
	'use strict';

	angular.module('mainMenu', []);
})();