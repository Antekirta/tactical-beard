(function() {
	'use strict';

	var infoPage = angular.module('infoPage');

	infoPage.controller('infoPageCtrl', ['$scope', function($scope) {

	}]);
})();