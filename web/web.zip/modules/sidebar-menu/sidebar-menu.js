(function() {
	'use strict';

	angular.module('sidebarMenu', []);
})();