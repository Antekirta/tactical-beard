(function() {
	'use strict';

	angular.module('utils', []);
})();