(function() {
	'use strict';

	angular.module('sidebarAdditional', []);
})();