(function() {
	'use strict';

	var bookmarksPage = angular.module('bookmarksPage');

	bookmarksPage.controller('bookmarksPageCtrl', ['$scope', function($scope) {

	}]);
})();