(function() {
	'use strict';

	angular.module('bookmarksPage', []);
})();