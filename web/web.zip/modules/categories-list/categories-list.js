(function() {
	'use strict';

	angular.module('categoriesList', []);
})();