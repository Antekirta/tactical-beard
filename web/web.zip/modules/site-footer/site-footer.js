(function() {
	'use strict';

	angular.module('siteFooter', []);
})();