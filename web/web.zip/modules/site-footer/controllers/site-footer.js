(function() {
	'use strict';

	var siteFooter = angular.module('siteFooter');

	siteFooter.controller('siteFooterCtrl', ['$scope', function($scope) {

	}]);
})();