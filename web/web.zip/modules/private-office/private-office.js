(function () {
    'use strict';

    angular.module('privateOffice', []);
})();