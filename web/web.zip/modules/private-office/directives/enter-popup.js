(function () {
    'use strict';
})();