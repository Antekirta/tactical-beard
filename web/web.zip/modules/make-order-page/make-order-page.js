(function() {
	'use strict';

	angular.module('makeOrderPage', []);
})();