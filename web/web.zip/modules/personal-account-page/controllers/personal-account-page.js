(function() {
	'use strict';

	var personalAccountPage = angular.module('personalAccountPage');

	personalAccountPage.controller('personalAccountPageCtrl', ['$scope', function($scope) {

	}]);
})();