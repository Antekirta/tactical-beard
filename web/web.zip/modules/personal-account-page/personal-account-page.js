(function() {
	'use strict';

	angular.module('personalAccountPage', []);
})();