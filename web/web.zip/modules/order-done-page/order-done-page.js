(function() {
	'use strict';

	angular.module('orderDonePage', []);
})();