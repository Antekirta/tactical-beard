(function() {
	'use strict';

	angular.module('categoriesPage', []);
})();