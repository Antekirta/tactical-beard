(function () {
    'use strict';

    angular.module('registry')
        .constant('COUNTRIES', {
            'RUSSIA': {
                'ID': 176
            }
        });
})();