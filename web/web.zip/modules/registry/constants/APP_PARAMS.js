(function () {
    'use strict';

    const registry = angular.module('registry');

    registry.constant('MAX_EMAIL_LENGTH', 100);

    registry.constant('MAX_PHONE_NUMBER_LENGTH', 25);
})();