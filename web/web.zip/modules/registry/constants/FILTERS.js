(function() {
    'use strict';

    var registry = angular.module('registry');

    registry.constant('FILTERS', {
        'ALL_MANUFACTURERS': 'Все производители'
    });
})();