(function () {
    'use strict';

    angular.module('registry')
        .constant('PRODUCT_DICTIONARY', {
            'PRODUCT_ID': 'product_id',

            'QUANTITY': 'quantity'
        });
})();