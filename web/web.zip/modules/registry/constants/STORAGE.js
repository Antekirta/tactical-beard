(function () {
    'use strict';

    angular.module('registry')
        .constant('LOCAL_STORAGE', {
            BASKET: 'basket',

            SESSION: 'session'
        });
})();