(function() {
	'use strict';

	angular.module('enterPopup', []);
})();