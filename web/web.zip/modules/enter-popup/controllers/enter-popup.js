(function() {
	'use strict';

	var enterPopup = angular.module('enterPopup');

	enterPopup.controller('enterPopupCtrl', ['$scope', function($scope) {

	}]);
})();