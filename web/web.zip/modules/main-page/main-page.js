(function() {
	'use strict';

	angular.module('mainPage', []);
})();