(function() {
	'use strict';

	var mainPage = angular.module('mainPage');

	mainPage.controller('mainPageCtrl', ['$scope', function($scope) {

	}]);
})();